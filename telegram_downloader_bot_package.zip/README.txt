
📦 Telegram Downloader Bot - دليل التشغيل

1. تأكد أن Python مثبت.
2. لتثبيت المتطلبات، شغل:
   pip install aiogram yt-dlp

3. لتشغيل البوت:
   - اضغط مرتين على run_bot.bat
   - أو استخدم: python telegram_downloader_bot.py

4. أرسل رابط إلى البوت في تيليجرام وسيبدأ التحميل.

📝 ملاحظات:
- الكوكيز مدمجة داخل السكربت لدعم إنستغرام الخاص.
- تأكد من وجود ffmpeg لتجنب أخطاء الدمج.
